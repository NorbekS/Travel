let elBtn = document.querySelector('.js-btn');
let elNewTime = document.querySelector('.time-js');
let elModal = document.querySelector('.modal');
let elmodalOpen = document.querySelector('.more-details-js')
let elmodalToClose = document.querySelector('.to-close')

function myFunction() {
  elNewTime.classList.remove('new-time-d-none')
}

function myFunctionModal() {
  elModal.classList.add('modal-open')
}
function myFunctionModalToClose() {
  elModal.classList.remove('modal-open')
}

